// ==UserScript==
// @name         Xenforo Colours/Colors and yeet disappearance For Shoutbox
// @namespace    http://arcadiaservers.com/
// @version      0.4
// @description  No reason that it doesn't have it by default as it is still available
// @author       Gl1tch3t
// @match        http://arcadiaservers.com/index.php/taigachat
// @match        http://arcadiaservers.com/index.php
// @match        http://arcadiaservers.com/index.php?taigachat
// @match        https://arcadiaservers.com/index.php/taigachat
// @match        https://arcadiaservers.com/index.php
// @match        https://arcadiaservers.com/index.php?taigachat

// @match        http://arcadiaservers.com/index.php/taigachat/
// @match        http://arcadiaservers.com/index.php/
// @match        http://arcadiaservers.com/index.php?taigachat/
// @match        https://arcadiaservers.com/index.php/taigachat/
// @match        https://arcadiaservers.com/index.php/
// @match        https://arcadiaservers.com/index.php?taigachat/
// ==/UserScript==

console.log("Colours/yeet makers for shoutbox");

/*function insertColourBBCode()
{
    var bbCodeBut = document.getElementById("taigachat_toolbar");
    var newDomElement = "<button data-code=\"[color][/color]\" class=\"button taigachat_bbcode xenForoSkin\"><span class=\"mceIcon mce_bold\"></span></button>"
}
*/

var rndMsg = ["meat", "beat", "seat", "bleat", "feet", "heat", "neat", "Pete"];
var reg = new RegExp(/(y|Y|Ÿ|Ý|ý|ÿ|Ŷ|ŷ|Ÿ|Ȳ|ȳ)\s*(((œ|e|E|é|è|ê|ë|ē|Ĕ|ĕ|Ė|ė|Ę|ę|Ě|ě|È|É|Ê|Ë|ℯ|ⅇ|ℰ)\s*)+){2,}\s*(t|T|Ţ|ţ|Ť|ť|Ŧ|ŧ|Ț|ț)/g);

console.log("Colours/Yeet Meaters for shoutbox");

function getMessages()
{
    var shoutBox = document.getElementById("taigachat_box");
    var shoutBoxChildren = shoutBox.children[0].children;
    for(var i = 0; i <shoutBoxChildren.length; i++)
    {
        var message = shoutBoxChildren[i].children[3].children[1];
        yeetBeGone(message);
    }
}
function yeetBeGone(message)
{
    var text = message.textContent;
    var newText;
    if (reg.test(text)) {
        var word = Math.floor((Math.random() * 10) + 1);
        newText = text.replace(reg, rndMsg[word]);
        if (message.childNodes[0]) {
            message.childNodes[0].textContent = newText;
        }
        else {
            message.textContent = newText;
        }
    }
/*     if (message.childNodes[0]) {
    var x = message.childNodes[0].textContent = newText;
    console.log(x);
    } */
    //console.log(message.children[0] + message.textContent.outerHtml);
}

setInterval(getMessages, 1000); //Increase this if you are still seeing Yeet or any of its variants.
